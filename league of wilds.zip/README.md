# Wilds x League: Hunt as a Champion (working title)

## One sentence
In Monster Hunter Wilds, pick any League of Legends champion at quest start and hunt with their Q/W/E/R and passive on your hunter.

## Games
- Monster Hunter Wilds (monster-hunter-wilds): role "primary" (host). Loader: REFramework (Melty installs it). Mod scripts go in {game}/reframework/autorun.
- League of Legends (league-of-legends): role "companion". Never launched, never modded. Read-only access to the player's own install via "{game:league-of-legends}". Nothing from League is copied or uploaded.
- Solo only (v1). No recipe.multiplayer.

## Listing (draft, player-facing)
- Title: Wilds x League: Hunt as a Champion
- Tagline: Pick any League champion and take their skills into the hunt.
- Description: Choose a champion before each quest and fight Wilds monsters with their Q/W/E/R and passive. Champion names, icons and spell data are read from your own League of Legends install, so you need both games installed. Kits are approximations of the originals.
- License: free to play, credit required, remixing allowed.
- Credits: TBD. Creator name/handle not given yet. Ask the user before submit.
(Rewrite title/description to match the real build before create_mod.)

## First minute
Quest starts -> champion select overlay (searchable list, icons) -> confirm -> hunt begins with abilities bound and a cooldown HUD shown.

## Design rules
- Sheets in ./sheets are the source of truth. Change the sheet before code. Each row generates one code struct.
- Every cell marked null or verified:false is unfinished. Run the preflight below before each build.
- Champion data is imported at first run from "{game:league-of-legends}" into a cache on the player's PC (never uploaded, never in the release).
- Keep Wilds' anti-tamper in mind: use only REFramework's normal script route. Never work around anti-cheat. Check game_info for any flagged risk.

## Order of work (Claude Code / Codex on the user's PC)
1. Connect to Melty (use the connection command from the original Publish prompt; keep the token out of files and replies).
2. game_info for both games; search_mashups; mashup_info on the closest launched one.
3. Find both install folders. Set up universal-modder (skills/mod-any-game/SKILL.md).
4. Resolve every null in sheets/hooks.json against the real game (REFramework type/method names).
5. Work out League's file layout for champion/spell data and fill sheets/champion_schema.json (read-only).
6. Preflight, build, test in the running game, capture a real screenshot/clip with the champion select or an ability in use.
7. inspect_package, validate_recipe, one_click_check (companion league-of-legends in recipe), create_mod, upload, submit_release, screenshot, test_release, then ask before publish.

## Preflight checklist
- [ ] Every hook in hooks.json has a verified REFramework API target.
- [ ] Every ability_type referenced by a champion exists in ability_types.json.
- [ ] Every ability_type has hook_ref values that exist in hooks.json.
- [ ] Every keybind action maps to an ability slot.
- [ ] Importer produces a type for all four spells of every champion (fallbacks allowed, flagged "fallback").
- [ ] No League file is copied into the project or release.
